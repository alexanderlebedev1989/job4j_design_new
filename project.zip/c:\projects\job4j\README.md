[![Build Status](https://travis-ci.com/alexanderlebedev1989/job4j.svg?branch=master)](https://travis-ci.com/alexanderlebedev1989/job4j)
[![Coverage status](https://codecov.io/gh/alexanderlebedev1989/job4j/branch/master/graph/badge.svg)](https://codecov.io/gh/alexanderlebedev1989/job4j)

# job4j
первый модуль обучения Java
